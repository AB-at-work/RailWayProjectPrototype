import SettingsClient from "@/components/settings-client"

export default function SettingsPage() {
  return <SettingsClient />
}